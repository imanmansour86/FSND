# export DATABASE_URL='postgres://postgres:postgres@localhost:5432/postgres'
export AUTH0_DOMAIN="capstone-project1.us.auth0.com"
export ALGORITHMS=["RS256"]
export API_AUDIENCE="cast"

export DATABASE_URL="postgres://zrqvaxnkdeutqv:4eef4c908628413b708346232ef18747d242b5bfaa79a9e08a923c8b4f80c18c@ec2-54-158-222-248.compute-1.amazonaws.com:5432/d1jfbkulur93hr"

export FLASK_APP=app.py
export FLASK_DEBUG=True
export FLASK_ENVIRONMENT=debug